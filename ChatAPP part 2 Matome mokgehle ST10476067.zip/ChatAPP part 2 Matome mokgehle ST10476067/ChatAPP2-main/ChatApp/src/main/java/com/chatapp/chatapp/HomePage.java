package com.chatapp.chatapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomePage {
    private String username;

    public HomePage(String username) {
        this.username = username;
        showHomePage();
    }

    private void showHomePage() {
        JFrame frame = new JFrame("QuickChat - Home");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLayout(new GridLayout(4, 1, 10, 10));

        JLabel welcomeLabel = new JLabel("Welcome to QuickChat, " + username + "!", SwingConstants.CENTER);
        JButton sendButton = new JButton("Send Message");
        JButton recentButton = new JButton("Show Recently Sent Messages");
        JButton quitButton = new JButton("Quit");

        sendButton.addActionListener(e -> new MessageSender(username));
        recentButton.addActionListener(e -> JOptionPane.showMessageDialog(frame, "Coming Soon..."));
        quitButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(frame, "Goodbye " + username + "!");
            System.exit(0);
        });

        frame.add(welcomeLabel);
        frame.add(sendButton);
        frame.add(recentButton);
        frame.add(quitButton);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
