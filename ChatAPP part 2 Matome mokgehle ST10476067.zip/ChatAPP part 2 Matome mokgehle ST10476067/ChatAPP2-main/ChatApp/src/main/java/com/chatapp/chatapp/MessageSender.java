package com.chatapp.chatapp;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class MessageSender {

    private String username;
    private ArrayList<Message> sentMessages = new ArrayList<>();
    private JSONArray storedMessages = new JSONArray();

    public MessageSender(String username) {
        this.username = username;
        showMessageGUI();
    }

    // GUI to send a message
    public void showMessageGUI() {
        JFrame frame = new JFrame("Send Message");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1));

        JTextField recipientField = new JTextField();
        JTextArea messageArea = new JTextArea();
        JButton sendButton = new JButton("Send");

        panel.add(new JLabel("Recipient (with international code):"));
        panel.add(recipientField);
        panel.add(new JLabel("Enter your message (max 250 chars):"));
        panel.add(new JScrollPane(messageArea));

        frame.add(panel, BorderLayout.CENTER);
        frame.add(sendButton, BorderLayout.SOUTH);

        sendButton.addActionListener((ActionEvent e) -> {
            String recipient = recipientField.getText().trim();
            String messageText = messageArea.getText().trim();

            if (recipient.isEmpty() || messageText.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill in all fields.");
                return;
            }

            String numberValidation = validateRecipientNumber(recipient);
            if (!numberValidation.contains("success")) {
                JOptionPane.showMessageDialog(frame, numberValidation);
                return;
            }

            String lengthValidation = validateMessageLength(messageText);
            if (!lengthValidation.contains("ready")) {
                JOptionPane.showMessageDialog(frame, lengthValidation);
                return;
            }

            // Create message components
            String messageID = Message.generateMessageID();
            String messageHash = Message.createMessageHash(messageID, 1, messageText);

            // Create and process the message
            Message message = new Message(messageID, recipient, messageText, messageHash);
            String result = processMessageAction(1, message);

            JOptionPane.showMessageDialog(frame, message.printMessageInfo() + "\n\n" + result);

            // Clear fields
            recipientField.setText("");
            messageArea.setText("");
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public String validateMessageLength(String message) {
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int extra = message.length() - 250;
            return "Message exceeds 250 characters by " + extra + ", please reduce size.";
        }
    }

    public String validateRecipientNumber(String number) {
        if (Message.checkRecipientCell(number)) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code.";
        }
    }

    public String processMessageAction(int action, Message msg) {
        switch (action) {
            case 1:
                sentMessages.add(msg);
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete message.";
            case 3:
                JSONObject jsonMessage = new JSONObject();
                jsonMessage.put("MessageID", msg.generateMessageID());
                jsonMessage.put("Recipient", msg.printMessageInfo()); // could store `msg.getRecipient()` if available
                jsonMessage.put("Message", msg.printMessageInfo());
                jsonMessage.put("MessageHash", msg.createMessageHash(msg.generateMessageID(), action, username));
                storedMessages.add(jsonMessage);
                return "Message successfully stored.";
            default:
                return "Invalid selection.";
        }
    }

    public ArrayList<Message> getSentMessages() {
        return sentMessages;
    }

    public JSONArray getStoredMessages() {
        return storedMessages;
    }
}
